function showup1() {
    var acc1a = document.querySelector('.acc1-a');
    if (acc1a.style.display === 'block') {
        acc1a.style.display = 'none';
    } else {
        acc1a.style.display = 'block';
    }
}
var isPlus1 = true;

function plustominus1() {
    let theImage = document.getElementById('plus-icon1');
    if (isPlus1) {
        theImage.src = './assets/images/icon-minus.svg';
        isPlus1 = false;
    } else {
        theImage.src = './assets/images/icon-plus.svg';
        isPlus1 = true;
    }
}
function showup2() {
    var acc1a = document.querySelector('.acc2-a');
    if (acc1a.style.display === 'block') {
        acc1a.style.display = 'none';
    } else {
        acc1a.style.display = 'block';
    }
}
var isPlus2 = true;

function plustominus2() {
    let theImage = document.getElementById('plus-icon2');
    if (isPlus2) {
        theImage.src = './assets/images/icon-minus.svg';
        isPlus2 = false;
    } else {
        theImage.src = './assets/images/icon-plus.svg';
        isPlus2 = true;
    }
}
function showup3() {
    var acc1a = document.querySelector('.acc3-a');
    if (acc1a.style.display === 'block') {
        acc1a.style.display = 'none';
    } else {
        acc1a.style.display = 'block';
    }
}
var isPlus3 = true;

function plustominus3() {
    let theImage = document.getElementById('plus-icon3');
    if (isPlus3) {
        theImage.src = './assets/images/icon-minus.svg';
        isPlus3 = false;
    } else {
        theImage.src = './assets/images/icon-plus.svg';
        isPlus3 = true;
    }
}
function showup4() {
    var acc1a = document.querySelector('.acc4-a');
    if (acc1a.style.display === 'block') {
        acc1a.style.display = 'none';
    } else {
        acc1a.style.display = 'block';
    }
}
var isPlus4 = true;

function plustominus4() {
    let theImage = document.getElementById('plus-icon4');
    if (isPlus4) {
        theImage.src = './assets/images/icon-minus.svg';
        isPlus4 = false;
    } else {
        theImage.src = './assets/images/icon-plus.svg';
        isPlus4 = true;
    }
}